<?php
//*****************************************************************************************************************************
//@Author: Gerardo Julio V. Ancheta Jr.
//Group 11
//Team members: Lochlann O Neill, Keith Bullman, Daniels Pikurs, Gerardo Ancheta Jr. 
//Module: Year 03 Group Project
//Date: 21/11/2020 
//Fin-Ai Web app
//contact.php
//contact
//*****************************************************************************************************************************
if(isset($_POST['btnSend'])){
//=============================================================================================================================
//db connection
//=============================================================================================================================
    require_once './assets/php/dbconfig.php';
//------------------------------------------------------------------------------------------------------------------
//Initialize Variables
//------------------------------------------------------------------------------------------------------------------        
    $name = $_POST['name'];
    $client_email = $_POST['email'];
    $message = $_POST['message'];

//------------------------------------------------------------------------------------------------------------------
//Input Error Check
//------------------------------------------------------------------------------------------------------------------
    //Check if inputs are empty.
    if(empty($name) || empty($client_email) || empty($message)){
        header("Location: index.html?error=emptyfields");
        exit();
    }
    //Check if email input is valid.
    else if(!filter_var($client_email, FILTER_VALIDATE_EMAIL)){
        header("Location: index.html?error=invalidemail");
        exit();
    }
    //Check if username input characters are valid.
    else if(!preg_match("/^[a-zA-Z]*$/",$name)){
        header("Location: index.html?error=invalidname");
        exit();
    }
//------------------------------------------------------------------------------------------------------------------
//Escape the admin input to make it safe to place in a query
//------------------------------------------------------------------------------------------------------------------
    $safe_name = mysqli_real_escape_string($db, $name);
    $safe_client_email = mysqli_real_escape_string($db, $client_email);
    $safe_message = mysqli_real_escape_string($db, $message);         
//=============================================================================================================================
//sql query
//=============================================================================================================================
    //insert the client's message into the database.  
    $insert_client_message="INSERT INTO contact_db (client_name, client_email, client_message) VALUES ('$safe_name','$safe_client_email','$safe_message')";
    $sql_query_message = mysqli_query($db,$insert_client_message);
    if($sql_query_message){  
        //echo"<script>window.open('index.html')</script>";
        header("Location: index.html?messagesent=success");
        exit();
    }     
    mysqli_close($db);   			
}			
?>