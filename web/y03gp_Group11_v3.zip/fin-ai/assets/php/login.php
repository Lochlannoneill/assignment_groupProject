<?php
//====================================================================================================
//@Author: Gerardo Julio V. Ancheta Jr.
//Group 11
//Team members: Lochlann O Neill, Keith Bullman, Daniels Pikurs, Gerardo Ancheta Jr. 
//Module: Year 04 Group Project
//Date: 21/11/2020 
//Fin-Ai Web app
//login.php
//====================================================================================================
//------------------------------------------------------------------------------------------------------------------
//Connect to Database
//------------------------------------------------------------------------------------------------------------------
$db = mysqli_connect('localhost', 'root', '', 'finAi_db') or die('Unable To Connect');

//------------------------------------------------------------------------------------------------------------------
//Error Check
//------------------------------------------------------------------------------------------------------------------
//Connection error output
if (!$db){
echo '<p>Sorry! CanU+02019t connect to database</p>'; 
exit();
}
//Set the character set
$charset_set = mysqli_set_charset ($db, 'utf8');

//Character error output
if (!$charset_set){
echo '<p>Sorry! CanU+02019t set character set</p>';
exit();
}
//------------------------------------------------------------------------------------------------------------------
//Initialize Variables
//------------------------------------------------------------------------------------------------------------------
// Criteria to search for
$username = $_POST['username'];
$password = $_POST['pwdInput'];

//------------------------------------------------------------------------------------------------------------------
//MySQL Query
//------------------------------------------------------------------------------------------------------------------
$queryBanker = "SELECT * FROM banker_db WHERE username = '$username' && password = '$password'";    
$resultBanker = mysqli_query($db, $queryBanker);

$queryBroker = "SELECT * FROM broker_db WHERE username = '$username' && password = '$password'";    
$resultBroker = mysqli_query($db, $queryBroker);

//------------------------------------------------------------------------------------------------------------------
//Results/Statements
//------------------------------------------------------------------------------------------------------------------
 // If user exists in banker_db table bring to user home page
// NOTE: The user is succesfully searched for but does not set as logged in
if(mysqli_num_rows($resultBanker) > 0){
  while ($row = mysqli_fetch_array($resultBanker)){
    $fname = $row['fName'];
	$lname = $row['lName'];
	
  }
	echo "$fname", " " ,"$lname";
	include 'index.html';
}

// If user exists in broker_db table bring to user home page
// NOTE: The user is succesfully searched for but does not set as logged in
else if (mysqli_num_rows($resultBroker) > 0){
	
	while ($row = mysqli_fetch_array($resultBroker)){
    
	$fname = $row['fName'];
	$lname = $row['lName'];
  }
	echo "$fname", " " ,"$lname";
	include 'index.html';
}
	    // If user is not found print message
		else{ 
			$error = "<script type='text/javascript'>alert('Your Login Name or Password is invalid!!!');</script>";
			include 'loginPage.html';
		}
    // Close database connection
    //mysqli_free_result($result);
    mysqli_close($db);


?>