<!--
@Author: Gerardo Julio V. Ancheta Jr.
Group 11
Team members: Lochlann O Neill, Keith Bullman, Daniels Pikurs, Gerardo Ancheta Jr. 
Module: Year 04 Group Project
Date: 21/11/2020 
Fin-Ai Web app
registerPage.php
-->
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Fin-Ai Login</title>
		<meta charset="utf-8">
		<!--===============================================================================================-->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="assets/css/registerStyles.css"/>
		<!--===============================================================================================-->
		<link rel="icon" type="image/png" href="img/finAi-logo.png" alt="Fin-Ai Logo"/>
		<!--===============================================================================================-->
			<script>
				window.onload = function(){
					document.getElementById('bankerForm').style.display = 'none';
					document.getElementById('brokerForm').style.display = 'none';
				}
				function showHid(x){
					//if(document.getElementById('rdBtnBanker').checked){
					if(x.type="radio"){
						if(x==0){	
							document.getElementById('bankerForm').style.display = 'block';
							document.getElementById('brokerForm').style.display = 'none';
						}
						else if(x==1){//if(document.getElementById('rdBtnbroker').checked){
							document.getElementById('brokerForm').style.display = 'block';
							document.getElementById('bankerForm').style.display = 'none';
						}
					}
				}
				function validBanker(){
				/*	var username = document.bankerReg.username.value;
					var email = document.bankerReg.email.value;
					var password = document.bankerReg.password.value;*/
					var username = document.forms["bankerReg"]["username"];
					var email = document.forms["bankerReg"]["emailInput"];
					var password = document.forms["bankerReg"]["pwdInput"];
			
					//check size field
					if(username.value==""){
						alert("Empty Fields!! Should not be blank");
						username.focus();
						return false;
					}
					if(email.value==""){
						alert("Empty Fields!! Should not be blank");
						email.focus();
						return false;
					}
					if(password.value==""){
						alert("Empty Fields!! Should not be blank");
						password.focus();
						return false;
					}
					if(password.length<8 || password.length>8){
						alert("Must contain: One number, One uppercase, lowercase letter and at least 8 characters ");
						return false;
					}
					var str=username.slice(0,1);
					if(username.slice(0,1)=="_"||username.slice(0,1)=="@"||str.match(/[0-9]/g)!=null){
						alert("Username should not start with _, @and Number");
						return false;
					}
				}
				function validBroker(){
				/*	var username = document.brokerReg.username.value;
					var email = document.brokerReg.email.value;
					var password = document.brokerReg.password.value;*/
					var username = document.forms["brokerReg"]["username"];
					var email = document.forms["brokerReg"]["email"];
					var password = document.forms["brokerReg"]["pwdInput"];
					var bkName = document.forms["brokerReg"]["dpdbkName"];
				
					//check size field
					if(username.value==""){
						alert("Empty Fields!! Should not be blank");
						username.focus();
						return false;
					}
					if(email.value==""){
						alert("Empty Fields!! Should not be blank");
						email.focus();
						return false;
					}
					if(password.value==""){
						alert("Empty Fields!! Should not be blank");
						password.focus();
						return false;
					}
					if(bkName.value==""){
						alert("Empty Fields!! Should not be blank");
						bkName.focus();
						return false;
					}
					if(password.length<8 || password.length>8){
						alert("Must contain: One number, One uppercase, lowercase letter and at least 8 characters ");
						return false;
					}
					var str=username.slice(0,1);
					if(username.slice(0,1)=="_"||username.slice(0,1)=="@"||str.match(/[0-9]/g)!=null){
						alert("Username should not start with _, @and Number");
						return false;
					}
				}	
			</script>
	</head>	
	<body>
		<div class="logo">
			<a href="index.html"><img src="img/finAi-logo.png" alt="Fin-Ai Logo" width="100px" height="50px"/></a>
		</div>	
			<div class="container">
			<h1>REGISTER FORM</h1>	
				<hr>
					<div>
						<label for="profession"><b>Profession:</b></label>
						<input type="radio" name="formtype" id="rdBtnBanker" onclick="showHid(0);" value="Banker"><label>Banker</label>
															
						<input type="radio" name="formtype" id="rdBtnbroker" onclick="showHid(1);" value="Broker"><label>Broker</label>					
					</div>
				<hr>
				<p>Please fill in this form to create an account.</p>
				
				<!-- BANKER REGISTARATION: -->
				<div id="bankerForm" style="display:none;">					
					<form action="assets/php/bankerReg.php" method="POST" onsubmit="return validBanker();" name="bankerReg">
						<hr>
						<h3>BANKER REGISTRATION</h3>
							<div>
								<label for="username"><b>Username</b></label>
								<input type="text" placeholder="Enter Username" name="username" id="username" 
									pattern="[A-Za-z ']+" autocomplete="off">
							</div>
							<div>	
								<label for="fName"><b>Firstname</b></label>
								<input type="text" placeholder="Enter Firstname" name="fNameInput" id="fNameInput" 
									pattern="[A-Za-z]{1,}" autocomplete="off">
							</div>
							<div>
								<label for="lName"><b>Surname</b></label>
								<input type="text" placeholder="Enter Surname" name="lNameInput" id="lNameInput" 
									pattern="[A-Za-z ']+" autocomplete="off">
							</div>
							<div>		
								<label for="telNo"><b>Telephone Number</b></label>
								<input type="numeric" placeholder="Enter Tel No: 0210101010" name="telNoInput" id="telNoInput" 
									pattern="[0-9]{10}">		
							</div>
							<div>	
								<label for="emailInput"><b>Email</b></label>				
								<input type="text" placeholder="Enter Email: example@gmail.com" name="emailInput" id="emailInput"
									pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" autocomplete="off">
							</div>
							<div>
								<div class="tooltip"><label for="password"><b>Password</b></label>
									<span class="tooltiptext">Must contain: One number, One uppercase,  
															lowercase letter and at least 8 characters
									</span>
								</div>
											
								<label for="passwordInfo"></label>
								
								<input type="password" placeholder="Enter Password: Example123" name="pwdInput" 
											pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}">
							</div>			
						<button type="submit" class="btnRegister">REGISTER</button>
					</form>	
				<!-- Broker REGISTARATION: -->				
				<div id="brokerForm" style="display:none;">				
					<form action="assets/php/brokerReg.php" method="POST" onsubmit="return validBroker();" name="brokerReg">
						<hr>
						<h3>BROKER REGISTRATION</h3>
							<div>
								<label for="username"><b>Username</b></label>
								<input type="text" placeholder="Enter Username" name="username" id="username" 
									pattern="[A-Za-z ']+" autocomplete="off">
							</div>
							<div>	
								<label for="fName"><b>Firstname</b></label>
								<input type="text" placeholder="Enter Firstname" name="fNameInput" id="fNameInput" 
									pattern="[A-Za-z]+" autocomplete="off">
							</div>
							<div>	
								<label for="lName"><b>Surname</b></label>
								<input type="text" placeholder="Enter Surname" name="lNameInput" id="lNameInput" 
									pattern="[A-Za-z ']+" autocomplete="off">
							</div>
							<!--<div>	
								<label for="address"><b>Practice Address:</b></label>
								<input type="text" placeholder="Enter Address Line 1" name="addressInput1" id="addressInput1" 
									autocomplete="off">
									
								<input type="text" placeholder="Enter Address Line 2" name="addressInput2" id="addressInput2">
								
								<input type="text" placeholder="Enter City" name="addressInput3" id="addressInput3">
							</div> -->
							<div>
								<label for="telNoInput"><b>Telephone Number</b></label>
								<input type="numeric" placeholder="Enter Tel No: 0210101010" name="telNoInput" id="telNoInput"
									pattern="[0-9]{10}">		
							</div>
							<div>		
								<label for="email"><b>Email</b></label>
								<input type="text" placeholder="Enter Email: example@gmail.com" name="emailInput" id="emailInput" 
									pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" autocomplete="off">
							</div>
							<div>
								<div class="tooltip"><label for="password"><b>Password</b></label>
									<span class="tooltiptext">Must contain: One number, One uppercase,  
															lowercase letter and at least 8 characters
									</span>
								</div>
											
								<label for="passwordInfo"></label>
								
								<input type="password" placeholder="Enter Password: Example123" name="pwdInput" 
											pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}">
							</div>
							<div>	
							<!--<label for="bankerName"><b>Banker's Name</b></label>
								<select name="dpdbkName">
									<option disabled selected>Select a Display Name</option>
										<?php
											//------------------------------------------------------------------------------------------------------------------
											//Connect to Database
											//------------------------------------------------------------------------------------------------------------------
											$db = mysqli_connect('localhost', 'root', '') or die('Unable To Connect');

											//Select Database
											$db_Name = mysqli_select_db ($db, 'finAi_db');//<Database Name>
											//------------------------------------------------------------------------------------------------------------------
											//Error Check
											//------------------------------------------------------------------------------------------------------------------
											//Connection error output
											if (!$db){
												echo '<p>Sorry! CanU+02019t connect to database</p>'; 
												exit();
											}
											//Set the character set
											$charset_set = mysqli_set_charset ($db, 'utf8');

											//Character error output
											if (!$charset_set){
												echo '<p>Sorry! CanU+02019t set character set</p>';
												exit();
											}
											//------------------------------------------------------------------------------------------------------------------
											//Send Query
											//------------------------------------------------------------------------------------------------------------------
											//$queryName = "SELECT (name) from banker_db";
											//$resultName = mysqli_query ($db, $queryName);
											$rUserName = mysqli_query ($db, "SELECT username FROM banker_db");

											//------------------------------------------------------------------------------------------------------------------
											//Output Result, List User from banker_db
											//------------------------------------------------------------------------------------------------------------------
											if($rUserName > 0){
												while($rowUserName = mysqli_fetch_array($resultName)) {
													echo '<option value='" . $rowUserName["username"] . "'>'. $rowUserName["username"].'</option>';
												}
											}
										?>
								</select>	
							</div> -->
							<div>	
								<label for="bankerName"><b>Banker's Name</b></label>
								<input type="text" placeholder="Enter Your Banker's Name" name="bkName" id="bkName" 
									pattern="[A-Za-z]+" autocomplete="off">
							</div>
						<button type="submit" class="btnRegister">REGISTER</button>
					</form>
				</div>			
				<hr>
				<p>By creating an account you agree to our <a href="tp.html">Terms & Privacy</a>.</p>				
				<div class="signin">
					<p>Already have an account? <a href="loginPage.html">SIGN IN</a>.</p>
					<p>Back To <a href="index.html" style="text-decoration: none">Home Page</a>.</p>
				</div>
			</div>	<!-- End of div "container" -->	
	</body>
</html>