url:
localhost/fin-ai/

import db to:=
localhost/phpmyadmin
db:
finai_db