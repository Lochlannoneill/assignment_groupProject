<?php
//====================================================================================================
//@Author: Gerardo Julio V. Ancheta Jr.
//Group 11
//Team members: Lochlann O Neill, Keith Bullman, Daniels Pikurs, Gerardo Ancheta Jr. 
//Module: Year 04 Group Project
//Date: 21/11/2020 
//Fin-Ai Web app
//bankerReg.php
//====================================================================================================
if(isset($_POST['btnRegister'])){
	//------------------------------------------------------------------------------------------------------------------
	//Connect to Database
	//------------------------------------------------------------------------------------------------------------------
		$db = mysqli_connect('localhost', 'root', '', 'finAi_db') or die('Unable To Connect');

	//------------------------------------------------------------------------------------------------------------------
	//Error Check
	//------------------------------------------------------------------------------------------------------------------
		//Connection error output
		if (!$db){
		echo '<p>Sorry! CanU+02019t connect to database</p>'; 
		exit();
		}
		//Set the character set
		$charset_set = mysqli_set_charset ($db, 'utf8');

		//Character error output
		if (!$charset_set){
		echo '<p>Sorry! CanU+02019t set character set</p>';
		exit();
		}
	//------------------------------------------------------------------------------------------------------------------
	//Initialize Variables
	//------------------------------------------------------------------------------------------------------------------
		$username = $_POST['username'];
		$fName = $_POST['fNameInput'];
		$lName = $_POST['lNameInput'];
		$telNo = $_POST['telNoInput'];
		$email = $_POST['emailInput'];
		$password = $_POST['pwdInput'];

	//------------------------------------------------------------------------------------------------------------------
	//MySQL Query
	//------------------------------------------------------------------------------------------------------------------
		$queryBanker = "SELECT * FROM banker_db WHERE username = '$username' && email = '$email'";    
		$resultBanker = mysqli_query($db, $queryBanker);

	//------------------------------------------------------------------------------------------------------------------
	//Results/Statements
	//------------------------------------------------------------------------------------------------------------------
		//Check for Empty input.
		if(empty($username) || empty($fName) || empty($lName) || empty($telNo) || empty($email) || empty($password)){
			$emptyError = "<script type='text/javascript'>alert('You didn't fill in all fields!');</script>";
			header("Location: registerPage.php?register=empty");
			exit();
		}
		//Check if username already exist.
		elseif(mysqli_num_rows($resultBanker) > 0){
		  while ($row = mysqli_fetch_array($resultBanker)){
		    $username = $row['username'];
			$email = $row['email'];
			
		  }
			$bankerExist = "User already Exist!!";
			header("Location: registerPage.php?register=invaliduser");		
			//include 'registerPage.html';
			exit();
		}
	//------------------------------------------------------------------------------------------------------------------
	//Send SQL query & store the result to the database 
	//------------------------------------------------------------------------------------------------------------------
		else{
			$queryIns = "INSERT INTO banker_db (username, fName, lName, telNo, email, password) VALUES ('$username','$fName', '$lName', '$telNo', '$email', '$password')";
			$result = mysqli_query($db, $queryIns);
		}

		/* Check if the query was successful */
			if ($result){
		//		echo "<script type='text/javascript'>alert('User was added successfully')</script>";
				echo '<p>User was added successfully!!</p>';
			}
			else{
		//		echo "<script type='text/javascript'>alert('User was added unsuccessfully')</script>";
				echo '<p>User was added unsuccessfully!!</p>';
			}
}
?>