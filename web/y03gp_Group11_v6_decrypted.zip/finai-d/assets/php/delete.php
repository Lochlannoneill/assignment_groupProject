<?php
//*****************************************************************************************************************************
//@Author: Gerardo Julio V. Ancheta Jr.
//Group 11
//Team members: Lochlann O Neill, Keith Bullman, Daniels Pikurs, Gerardo Ancheta Jr. 
//Module: Year 03 Group Project
//Date: 21/11/2020 
//Fin-Ai Web app
//delete.php
//delete user
//*****************************************************************************************************************************
if(isset($_POST['btnDelete'])){
    $broker_username = $_POST['btnDelete'];
//=============================================================================================================================
//db connection
//=============================================================================================================================
    require_once 'dbconfig.php'; 
//=============================================================================================================================
//db query
//=============================================================================================================================
    $del_user_query ="DELETE FROM bankerdata_db WHERE broker_username = '$broker_username'";
    $del_result = mysqli_query($db, $del_user_query);
    
    if($del_result){
        //echo "<p class='p-success'>User delete success</p>";
        header("location: admin_view.php?delete=success");
        exit();
    }else{
        //echo "<p class='p-fail'>User not deleted</p>";
        header("location: admin_view.php?delete=fail");
    }			
}
//$del_user $_GET['btnDelete'];
//=============================================================================================================================
//db connection
//=============================================================================================================================
/*require_once 'dbconfig.php'; 
    $id = $_GET['btnDelete'];

//=============================================================================================================================
//db query
//=============================================================================================================================
    $del_user_query ="DELETE FROM bankerdata_db WHERE id = '$id'";
    $del_result = mysqli_query($db, $del_user_query);
    
    if($del_result){
        //echo "<p class='p-success'>User delete success</p>";
        header("location: admin_view.php?delete=success", "_self");
        exit();
    }else{
        //echo "<p class='p-fail'>User not deleted</p>";
        header("location: admin_view.php?delete=fail", "_self");
    } */
?>