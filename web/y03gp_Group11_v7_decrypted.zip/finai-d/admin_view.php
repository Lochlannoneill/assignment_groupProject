<?php
//*****************************************************************************************************************************
//@Author: Gerardo Julio V. Ancheta Jr.
//Group 11
//Team members: Lochlann O Neill, Keith Bullman, Daniels Pikurs, Gerardo Ancheta Jr. 
//Module: Year 03 Group Project
//Date: 21/11/2020 
//Fin-Ai Web app
//admin_view.php
//admin dashboard
//*****************************************************************************************************************************
session_start();  
  
if(!$_SESSION['username']){  
  
    header("location:loginPage.php?action=login");//redirect to the login page to secure the welcome page without login access.  
}  
  
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Banker Dashboard</title>
		<meta charset="utf-8">
		<!--===============================================================================================--> 
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!--===============================================================================================-->  
		<link rel="icon" type="image/png" href="img/finAi-logo.png" alt="Fin-Ai Logo"/>
		<!--===============================================================================================-->
		<link rel="stylesheet" type="text/css" href="./assets/css/admin_view_styles.css">
		<!--===============================================================================================-->
		<link rel="preconnect" href="https://fonts.gstatic.com">
		<link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">
		<!--===============================================================================================-->
	</head>
	<body>
		<div class="header-container">		
			<img src="img/finAi-logo.png" alt="Fin-Ai Logo" width="100px" height="50px"/>		
			<div class="wrapper">	
				<ul class="lblUser">
					<li color="black"><?php echo $_SESSION['username']?></li>
				</ul>
				<ul class="ulLogout">	
					<li><button class="btnLogout" onClick="window.location='logout.php';">Logout</button></li>					
				</ul>
			</div>	
		</div>
		<br></br>
		<h1>Banker Dashboard</h1>
		<br></br>
		<hr>
		<div class="main-container">
			<table class="table-data">
				<thead>  
			        <tr>  
			            <th>#</th>  
			            <th>Broker Username</th>  
			            <th>Broker E-mail</th>
			            <th>Broker Age</th>
						<th>Broker Income</th>
						<th>Delete User</th>
			        </tr> 
	        	</thead>
		        <tbody>
		        	<?php
		        	//------------------------------------------------------------------------------------------------------------------
					//Connect to Database
					//------------------------------------------------------------------------------------------------------------------  
						//include("assets/php/dbconfig.php");
		        		//include("dbconfig.php");
		        		require_once 'assets/php/dbconfig.php';
					//------------------------------------------------------------------------------------------------------------------
					//Initialize Variables
					//------------------------------------------------------------------------------------------------------------------
						//Grab username whoever is logged in and insert into db.	
		        		$admin_session_username = $_SESSION['username'];
		        		$counter = 1;
					//------------------------------------------------------------------------------------------------------------------
					//Send Query
					//------------------------------------------------------------------------------------------------------------------
						//sql query, select user from tbl where user equal to whoever is logged in.
						$view_users_query="SELECT * FROM bankerdata_db WHERE admin_username = '$admin_session_username'";
						$result=mysqli_query($db,$view_users_query);//here run the sql query.  

						while($row=mysqli_fetch_array($result)){ //while look to fetch the result and store in a array $row.
							//$id = $row[0];  
							$broker_username=$row[2];  
							$broker_email=$row[3];
							$broker_age=$row[4]; 
							$broker_income=$row[5];
					?>
						<tr>
							<!--here showing results in the table -->  
							<td><?php echo $counter++; ?></td>  
							<td><?php echo $broker_username; ?></td>  
							<td><?php echo $broker_email;  ?></td>
							<td><?php echo $broker_age;  ?></td> 
							<td>€<?php echo $broker_income;  ?></td>
							<form action="admin_view.php" method="post">
								<td><button type="submit" name="btnDelete" value="<?php echo $broker_username; ?>" class="btnDelete">Delete</button></td>
							</form>	     
						</tr> 
					<?php } ?> 
				</tbody>
			</table>
		</div>
		<hr>
		<br></br>
		<h1>Customer Contact</h1>
		<br></br>
		<hr>							
		<div class="sub-container">
			<table class="table-message">
				<thead>  
			        <tr>  
			            <th>#</th>  
			            <th>Name</th>  
			            <th>Customer E-mail</th>
						<th>Message</th>
						<th>Delete User</th>
			        </tr> 
	        	</thead>
		        <tbody>
		        	<?php
		        	//------------------------------------------------------------------------------------------------------------------
					//Connect to Database
					//------------------------------------------------------------------------------------------------------------------  
						//include("assets/php/dbconfig.php");
		        		//include("dbconfig.php");
		        		require_once 'assets/php/dbconfig.php';
					//------------------------------------------------------------------------------------------------------------------
					//Initialize Variables
					//------------------------------------------------------------------------------------------------------------------
		        		$counter = 1;
					//------------------------------------------------------------------------------------------------------------------
					//Send Query
					//------------------------------------------------------------------------------------------------------------------
						//sql query, select user from tbl where user equal to whoever is logged in.
						$view_query_contact="SELECT * FROM contact_db";
						$query_result=mysqli_query($db,$view_query_contact);//here run the sql query.  

						while($row_contact=mysqli_fetch_array($query_result)){ //while look to fetch the result and store in a array $row_contact.  
							$client_name=$row_contact[1];  
							$client_email=$row_contact[2];
							$client_message=$row_contact[3]; 
					?>
						<tr>
							<!--here showing results in the table -->  
							<td><?php echo $counter++; ?></td>  
							<td><?php echo $client_name; ?></td>  
							<td><?php echo $client_email;  ?></td>
							<td><?php echo $client_message;  ?></td> 
							<td><button name="#" class="btnDelete">Delete</button></td>     
						</tr> 
					<?php } ?> 
				</tbody>
			</table>
		</div>
	</body>
</html>